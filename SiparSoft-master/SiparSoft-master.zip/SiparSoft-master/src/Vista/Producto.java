/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Vista;

/**
 *
 * @author MIGUEL
 */
public class Producto {
 private String codigo;
 private String nombre_productor;
 private String tipo_producto;
 
 
 public void crear_producto(){
     
 }
         
 public void actualizar_producto(){
     
 }
  
public boolean activar_producto(){
    return true;
}
}
