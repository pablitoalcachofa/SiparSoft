/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Vista;


/**
 *
 * @author MIGUEL
 */
public class Bodega {
    
    private String identificacion;
    private String nombre;
    // private date fecha_nacimiento;
    private int edad;
    
 public void gestionar_productos(){
 
 }
 public void gestionar_pedidos(){
 
 }
    
    
}
